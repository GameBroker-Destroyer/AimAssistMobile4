# AimAssist Mobile

A small Android companion-settings app with a dark/neon-green interface.

## Build an APK
1. Install Android Studio on a computer.
2. Open this `AimAssistMobile` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

## Important
This is a settings companion/demo. It does not attach to Roblox, inject code, read game memory, or control Roblox's camera. The aim-assist logic for a game you own must be implemented inside that Roblox experience using Roblox Studio and appropriate server-side validation.

## Project details
- Kotlin
- Minimum Android version: Android 6.0 (API 23)
- Target SDK: 35
- No internet permission or external services required
