package com.example.aimassistmobile

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.content.Context

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 21, 29)
    private val panel = Color.rgb(27, 39, 51)
    private val green = Color.rgb(66, 232, 137)
    private val muted = Color.rgb(167, 180, 197)
    private val white = Color.WHITE
    private lateinit var status: TextView
    private lateinit var toggle: Switch
    private lateinit var smoothnessValue: TextView
    private lateinit var prefs: android.content.SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("aimassist_settings", Context.MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(20), dp(24), dp(20), dp(18))
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(12))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val header = TextView(this).apply {
            text = "AIMASSIST"
            textSize = 27f
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            setTextColor(white)
            letterSpacing = 0.08f
        }
        content.addView(header)
        content.addView(label("ROBLOX COMPANION CONTROL PANEL"))

        val hero = card()
        hero.addView(label("AIM ASSIST STATUS"))
        status = TextView(this).apply {
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(muted)
            text = "OFF"
        }
        hero.addView(status)
        toggle = Switch(this).apply {
            text = "Enable companion mode"
            setTextColor(white)
            isChecked = prefs.getBoolean("enabled", false)
            buttonTintList = android.content.res.ColorStateList.valueOf(green)
        }
        hero.addView(toggle)
        toggle.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("enabled", checked).apply()
            status.text = if (checked) "ON" else "OFF"
            status.setTextColor(if (checked) green else muted)
        }
        status.text = if (toggle.isChecked) "ON" else "OFF"
        status.setTextColor(if (toggle.isChecked) green else muted)
        content.addView(hero)

        val settings = card()
        settings.addView(sectionTitle("TRACKING SETTINGS"))
        settings.addView(label("These are saved preferences for your own game project."))
        settings.addView(space(10))

        settings.addView(fieldTitle("Target type"))
        val target = spinner(listOf("Players", "NPCs", "Training dummies"), "target")
        settings.addView(target)

        settings.addView(space(8))
        settings.addView(fieldTitle("Aim point"))
        val aimPoint = spinner(listOf("Head", "Upper body", "Torso"), "aim_point")
        settings.addView(aimPoint)

        settings.addView(space(14))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(fieldTitle("Smoothness"), LinearLayout.LayoutParams(0, -2, 1f))
        smoothnessValue = TextView(this).apply {
            setTextColor(green)
            textSize = 14f
            text = "${prefs.getInt("smoothness", 15)}%"
        }
        row.addView(smoothnessValue)
        settings.addView(row)

        val seek = SeekBar(this).apply {
            max = 100
            progress = prefs.getInt("smoothness", 15)
            progressTintList = android.content.res.ColorStateList.valueOf(green)
            thumbTintList = android.content.res.ColorStateList.valueOf(green)
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                smoothnessValue.text = "$value%"
                if (fromUser) prefs.edit().putInt("smoothness", value).apply()
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        settings.addView(seek)
        content.addView(settings)

        val connection = card()
        connection.addView(sectionTitle("CONNECTION"))
        connection.addView(label("Roblox companion: Not connected"))
        connection.addView(label("This app does not connect to, inject into, or control the Roblox client."))
        content.addView(connection)

        val save = Button(this).apply {
            text = "SAVE SETTINGS"
            setTextColor(Color.rgb(8, 25, 16))
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            backgroundTintList = android.content.res.ColorStateList.valueOf(green)
            setOnClickListener {
                prefs.edit()
                    .putBoolean("enabled", toggle.isChecked)
                    .putString("target", target.selectedItem.toString())
                    .putString("aim_point", aimPoint.selectedItem.toString())
                    .apply()
                Toast.makeText(this@MainActivity, "Settings saved", Toast.LENGTH_SHORT).show()
            }
        }
        content.addView(save, LinearLayout.LayoutParams(-1, dp(52)).apply {
            topMargin = dp(14)
        })

        val footer = TextView(this).apply {
            text = "AIMASSIST MOBILE  •  VERSION 1.0"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(muted)
            setPadding(0, dp(10), 0, 0)
        }
        root.addView(footer)
        setContentView(root)
    }

    private fun spinner(items: List<String>, key: String): Spinner {
        val s = Spinner(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        s.adapter = adapter
        val saved = prefs.getString(key, items.first()) ?: items.first()
        val index = items.indexOf(saved).let { if (it < 0) 0 else it }
        s.setSelection(index)
        s.backgroundTintList = android.content.res.ColorStateList.valueOf(green)
        return s
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(15), dp(16), dp(15))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(panel)
            cornerRadius = dp(16).toFloat()
        }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(16)
        layoutParams = lp
    }

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 12f
        setTextColor(muted)
        setPadding(0, dp(5), 0, dp(5))
    }

    private fun sectionTitle(value: String) = TextView(this).apply {
        text = value
        textSize = 16f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(white)
        setPadding(0, 0, 0, dp(7))
    }

    private fun fieldTitle(value: String) = TextView(this).apply {
        text = value
        textSize = 14f
        setTextColor(white)
    }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
